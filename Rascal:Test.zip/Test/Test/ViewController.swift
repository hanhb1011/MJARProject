//
//  ViewController.swift
//  Test
//
//  Created by Gihyouk Lee on 21/01/2018.
//  Copyright © 2018 Gihyouk Lee. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var datalist = NSDictionary()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let baseURL = URL(string: "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=37.557772,127.000706&language=ko&radius=500&type=restaurant&key=AIzaSyCzY5m4aopjsOKjpDJOEFMLdY9Tl0ZlF2Y")
        
        do {
            self.datalist = try JSONSerialization.jsonObject(with:Data(contentsOf: baseURL!), options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
        } catch {
            print("Error loading Data")
        }
        
        print("abcde")
        
        print(self.datalist)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

