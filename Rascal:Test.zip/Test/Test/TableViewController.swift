//
//  TableViewController.swift
//  Test
//
//  Created by Gihyouk Lee on 29/01/2018.
//  Copyright © 2018 Gihyouk Lee. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
//        let detailPlace = getDetailPlace("ChIJfcd5eByjfDURTjuVpy9Yb0k")
//
//        if let name = detailPlace.name {
//            print(name)
//        }
//
//        if let fa = detailPlace.formatted_address {
//            print(fa)
//        }
//
//        if let fpn = detailPlace.formatted_phone_number {
//            print(fpn)
//        }
//
//        if let on = detailPlace.open_now {
//            print(on)
//        }
//
//        if let v = detailPlace.vicinity {
//            print(v)
//        }
        
        
        let places = getPlaceInfos(lat: "37.557772", lng: "127.000706")
        
        for place in places {
            print(place.lat + " " + place.lng + " " + place.place_id)
        }
    }

    func getPlaceInfos(lat: String, lng: String) -> [PlaceInfo]{
        var placeInfos :[PlaceInfo] = []
        var fullUrl :String = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=" + lat + "," + lng + "&language=ko&radius=500&type=restaurant&key=AIzaSyCzY5m4aopjsOKjpDJOEFMLdY9Tl0ZlF2Y"
        
        let url = URL(string: fullUrl)
        var datalist = NSDictionary()
        
        do {
            datalist = try JSONSerialization.jsonObject(with:Data(contentsOf : url!), options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
        }  catch {
            print("Error loading Data")
        }
        
        if let restaurants = datalist["results"] as? NSArray {
            for res in restaurants {
                if let restaurant = res as? NSDictionary {
                    var lat1 : String = ""
                    var lng1 : String = ""
                    var place_id1 : String = ""
                    
                    if let geometry = restaurant["geometry"] as? NSDictionary {
                        if let location = geometry["location"] as? NSDictionary {
                            if let lat = location["lat"] as? Double {
                                lat1 = String(lat)
                            }
                            
                            if let lng = location["lng"] as? Double {
                                lng1 = String(lng)
                            }
                            
                            
                        }
                    }
                    
                    if let place_id = restaurant["place_id"] as? String {
                        place_id1 = place_id
                    }
                    
                    placeInfos += [PlaceInfo(lat1, lng1, place_id1)]
                }
            }
        }
        
        
        return placeInfos
    }
    
    func getDetailPlace(_ place_id : String) -> DetailPlace {
        let place = DetailPlace()
        let fullUrl :String = "https://maps.googleapis.com/maps/api/place/details/json?placeid=" + place_id + "&language=ko&key=AIzaSyBmMU_ZnsgsjuCk5VAEoeRMt8DzMtj_Z5M"
        let url = URL(string: fullUrl)
        var datalist = NSDictionary()
        
        do {
            datalist = try JSONSerialization.jsonObject(with:Data(contentsOf : url!), options: JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
        }  catch {
            print("Error loading Data")
        }
        if let result = datalist["result"] as? NSDictionary {
            if let name = result["name"] as? String {
                place.name = name
            }
            
            if let formatted_address = result["formatted_address"] as? String {
                place.formatted_address = formatted_address
            }
            
            if let formatted_phone_number = result["formatted_phone_number"] as? String {
                place.formatted_phone_number = formatted_phone_number
            }
            
            if let opening_hours = result["opening_hours"] as? NSDictionary {
                if let open_now = opening_hours["open_now"] as? Bool {
                    place.open_now = open_now
                }
                
                if let weekday_text = opening_hours["weekday_text"] as? [String] {
                    place.weekday_text = weekday_text
                }
            }
            
            if let vicinity = result["vicinity"] as? String {
                place.vicinity = vicinity
            }
            
            if let photos = result["photos"] as? NSArray {
                for ph in photos {
                    if let photo = ph as? NSDictionary {
                        var height1 :String? = nil
                        if let height = photo["height"] as? Int {
                            height1 = String(height)
                        }
                        var width1 :String? = nil
                        if let width = photo["width"] as? Int {
                            width1 = String(width)
                        }
                        var photo_reference1 :String? = nil
                        if let photo_reference = photo["photo_reference"] as? String {
                            photo_reference1 = photo_reference
                        }
                        
                        if let height = height1, let width = width1, let photo_reference = photo_reference1 {
                            place.photos?.append(Photo(height, width, photo_reference))
                        }
                    }
                }
            }
            
        }
        
        return place
    }
    
    func getPhotoUrl(photos:[Photo]) -> [String] {
        var urls :[String] = []
        for photo in photos {
            let url :String = "https://maps.googleapis.com/maps/api/place/photo?maxwidth=" + photo.width + "&maxheight=" + photo.height +  "&photoreference=" + photo.photo_reference + "&key= AIzaSyCzY5m4aopjsOKjpDJOEFMLdY9Tl0ZlF2Y"
            urls.append(url)
        }
        
        return urls
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 0
    }

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
